// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Stroke {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.target_x = null;
      this.target_y = null;
      this.speed = null;
      this.penHeight = null;
      this.scale_done_dist = null;
    }
    else {
      if (initObj.hasOwnProperty('target_x')) {
        this.target_x = initObj.target_x
      }
      else {
        this.target_x = 0.0;
      }
      if (initObj.hasOwnProperty('target_y')) {
        this.target_y = initObj.target_y
      }
      else {
        this.target_y = 0.0;
      }
      if (initObj.hasOwnProperty('speed')) {
        this.speed = initObj.speed
      }
      else {
        this.speed = 0.0;
      }
      if (initObj.hasOwnProperty('penHeight')) {
        this.penHeight = initObj.penHeight
      }
      else {
        this.penHeight = 0.0;
      }
      if (initObj.hasOwnProperty('scale_done_dist')) {
        this.scale_done_dist = initObj.scale_done_dist
      }
      else {
        this.scale_done_dist = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Stroke
    // Serialize message field [target_x]
    bufferOffset = _serializer.float64(obj.target_x, buffer, bufferOffset);
    // Serialize message field [target_y]
    bufferOffset = _serializer.float64(obj.target_y, buffer, bufferOffset);
    // Serialize message field [speed]
    bufferOffset = _serializer.float64(obj.speed, buffer, bufferOffset);
    // Serialize message field [penHeight]
    bufferOffset = _serializer.float64(obj.penHeight, buffer, bufferOffset);
    // Serialize message field [scale_done_dist]
    bufferOffset = _serializer.float64(obj.scale_done_dist, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Stroke
    let len;
    let data = new Stroke(null);
    // Deserialize message field [target_x]
    data.target_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [target_y]
    data.target_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [speed]
    data.speed = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [penHeight]
    data.penHeight = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [scale_done_dist]
    data.scale_done_dist = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 40;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/Stroke';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7d2ccf528fbd03222e7b743f7f58eb79';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 target_x # target position on canvas in meters
    float64 target_y # target position on canvas in meters
    float64 speed # speed in m/s, hack: negative speed will be interpreted as a stop motion in seconds
    float64 penHeight # distance of the pen from the canvas in meters
    float64 scale_done_dist # this should be by default 1., larger values (like 2.) make the drawing less precise but "faster" in execution
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Stroke(null);
    if (msg.target_x !== undefined) {
      resolved.target_x = msg.target_x;
    }
    else {
      resolved.target_x = 0.0
    }

    if (msg.target_y !== undefined) {
      resolved.target_y = msg.target_y;
    }
    else {
      resolved.target_y = 0.0
    }

    if (msg.speed !== undefined) {
      resolved.speed = msg.speed;
    }
    else {
      resolved.speed = 0.0
    }

    if (msg.penHeight !== undefined) {
      resolved.penHeight = msg.penHeight;
    }
    else {
      resolved.penHeight = 0.0
    }

    if (msg.scale_done_dist !== undefined) {
      resolved.scale_done_dist = msg.scale_done_dist;
    }
    else {
      resolved.scale_done_dist = 0.0
    }

    return resolved;
    }
};

module.exports = Stroke;
