// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class SalientPoint {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.position = null;
      this.motion = null;
      this.umap = null;
      this.vmap = null;
      this.contrast = null;
    }
    else {
      if (initObj.hasOwnProperty('position')) {
        this.position = initObj.position
      }
      else {
        this.position = new geometry_msgs.msg.Point();
      }
      if (initObj.hasOwnProperty('motion')) {
        this.motion = initObj.motion
      }
      else {
        this.motion = 0.0;
      }
      if (initObj.hasOwnProperty('umap')) {
        this.umap = initObj.umap
      }
      else {
        this.umap = 0.0;
      }
      if (initObj.hasOwnProperty('vmap')) {
        this.vmap = initObj.vmap
      }
      else {
        this.vmap = 0.0;
      }
      if (initObj.hasOwnProperty('contrast')) {
        this.contrast = initObj.contrast
      }
      else {
        this.contrast = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SalientPoint
    // Serialize message field [position]
    bufferOffset = geometry_msgs.msg.Point.serialize(obj.position, buffer, bufferOffset);
    // Serialize message field [motion]
    bufferOffset = _serializer.float32(obj.motion, buffer, bufferOffset);
    // Serialize message field [umap]
    bufferOffset = _serializer.float32(obj.umap, buffer, bufferOffset);
    // Serialize message field [vmap]
    bufferOffset = _serializer.float32(obj.vmap, buffer, bufferOffset);
    // Serialize message field [contrast]
    bufferOffset = _serializer.float32(obj.contrast, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SalientPoint
    let len;
    let data = new SalientPoint(null);
    // Deserialize message field [position]
    data.position = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset);
    // Deserialize message field [motion]
    data.motion = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [umap]
    data.umap = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [vmap]
    data.vmap = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [contrast]
    data.contrast = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 40;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/SalientPoint';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '77b21d036cc548a00d1f9e3b297dff57';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    geometry_msgs/Point position
    float32 motion
    float32 umap
    float32 vmap
    float32 contrast
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SalientPoint(null);
    if (msg.position !== undefined) {
      resolved.position = geometry_msgs.msg.Point.Resolve(msg.position)
    }
    else {
      resolved.position = new geometry_msgs.msg.Point()
    }

    if (msg.motion !== undefined) {
      resolved.motion = msg.motion;
    }
    else {
      resolved.motion = 0.0
    }

    if (msg.umap !== undefined) {
      resolved.umap = msg.umap;
    }
    else {
      resolved.umap = 0.0
    }

    if (msg.vmap !== undefined) {
      resolved.vmap = msg.vmap;
    }
    else {
      resolved.vmap = 0.0
    }

    if (msg.contrast !== undefined) {
      resolved.contrast = msg.contrast;
    }
    else {
      resolved.contrast = 0.0
    }

    return resolved;
    }
};

module.exports = SalientPoint;
