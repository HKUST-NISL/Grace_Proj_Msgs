// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let facebox = require('./facebox.js');

//-----------------------------------------------------------

class faces {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.face_boxes = null;
      this.image_width = null;
      this.image_height = null;
    }
    else {
      if (initObj.hasOwnProperty('face_boxes')) {
        this.face_boxes = initObj.face_boxes
      }
      else {
        this.face_boxes = [];
      }
      if (initObj.hasOwnProperty('image_width')) {
        this.image_width = initObj.image_width
      }
      else {
        this.image_width = 0;
      }
      if (initObj.hasOwnProperty('image_height')) {
        this.image_height = initObj.image_height
      }
      else {
        this.image_height = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type faces
    // Serialize message field [face_boxes]
    // Serialize the length for message field [face_boxes]
    bufferOffset = _serializer.uint32(obj.face_boxes.length, buffer, bufferOffset);
    obj.face_boxes.forEach((val) => {
      bufferOffset = facebox.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [image_width]
    bufferOffset = _serializer.uint16(obj.image_width, buffer, bufferOffset);
    // Serialize message field [image_height]
    bufferOffset = _serializer.uint16(obj.image_height, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type faces
    let len;
    let data = new faces(null);
    // Deserialize message field [face_boxes]
    // Deserialize array length for message field [face_boxes]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.face_boxes = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.face_boxes[i] = facebox.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [image_width]
    data.image_width = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [image_height]
    data.image_height = _deserializer.uint16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 10 * object.face_boxes.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/faces';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '01b19e12d743adf8cea65e88e99f963f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    facebox[] face_boxes
    uint16 image_width
    uint16 image_height
    ================================================================================
    MSG: hr_msgs/facebox
    int16 id
    uint16 top
    uint16 left
    uint16 width
    uint16 height
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new faces(null);
    if (msg.face_boxes !== undefined) {
      resolved.face_boxes = new Array(msg.face_boxes.length);
      for (let i = 0; i < resolved.face_boxes.length; ++i) {
        resolved.face_boxes[i] = facebox.Resolve(msg.face_boxes[i]);
      }
    }
    else {
      resolved.face_boxes = []
    }

    if (msg.image_width !== undefined) {
      resolved.image_width = msg.image_width;
    }
    else {
      resolved.image_width = 0
    }

    if (msg.image_height !== undefined) {
      resolved.image_height = msg.image_height;
    }
    else {
      resolved.image_height = 0
    }

    return resolved;
    }
};

module.exports = faces;
