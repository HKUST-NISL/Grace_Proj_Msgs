
"use strict";

let EmotionAttentionResult = require('./EmotionAttentionResult.js');
let TrackingReIDResult = require('./TrackingReIDResult.js');

module.exports = {
  EmotionAttentionResult: EmotionAttentionResult,
  TrackingReIDResult: TrackingReIDResult,
};
