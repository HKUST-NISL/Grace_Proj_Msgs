// Auto-generated. Do not edit!

// (in-package hr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class TTSDataRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.txt = null;
      this.lang = null;
    }
    else {
      if (initObj.hasOwnProperty('txt')) {
        this.txt = initObj.txt
      }
      else {
        this.txt = '';
      }
      if (initObj.hasOwnProperty('lang')) {
        this.lang = initObj.lang
      }
      else {
        this.lang = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TTSDataRequest
    // Serialize message field [txt]
    bufferOffset = _serializer.string(obj.txt, buffer, bufferOffset);
    // Serialize message field [lang]
    bufferOffset = _serializer.string(obj.lang, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TTSDataRequest
    let len;
    let data = new TTSDataRequest(null);
    // Deserialize message field [txt]
    data.txt = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [lang]
    data.lang = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.txt.length;
    length += object.lang.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/TTSDataRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c8cbcfece38fa04d1eaadb06bee64ba2';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string txt
    string lang
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TTSDataRequest(null);
    if (msg.txt !== undefined) {
      resolved.txt = msg.txt;
    }
    else {
      resolved.txt = ''
    }

    if (msg.lang !== undefined) {
      resolved.lang = msg.lang;
    }
    else {
      resolved.lang = ''
    }

    return resolved;
    }
};

class TTSDataResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.data = null;
    }
    else {
      if (initObj.hasOwnProperty('data')) {
        this.data = initObj.data
      }
      else {
        this.data = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TTSDataResponse
    // Serialize message field [data]
    bufferOffset = _serializer.string(obj.data, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TTSDataResponse
    let len;
    let data = new TTSDataResponse(null);
    // Deserialize message field [data]
    data.data = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.data.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/TTSDataResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '992ce8a1687cec8c8bd883ec73ca41d1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string data
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TTSDataResponse(null);
    if (msg.data !== undefined) {
      resolved.data = msg.data;
    }
    else {
      resolved.data = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: TTSDataRequest,
  Response: TTSDataResponse,
  md5sum() { return '44a9c371f73f25f011c95281a881a70a'; },
  datatype() { return 'hr_msgs/TTSData'; }
};
