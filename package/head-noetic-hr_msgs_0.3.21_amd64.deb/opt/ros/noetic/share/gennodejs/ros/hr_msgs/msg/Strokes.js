// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Stroke = require('./Stroke.js');

//-----------------------------------------------------------

class Strokes {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.strokes = null;
    }
    else {
      if (initObj.hasOwnProperty('strokes')) {
        this.strokes = initObj.strokes
      }
      else {
        this.strokes = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Strokes
    // Serialize message field [strokes]
    // Serialize the length for message field [strokes]
    bufferOffset = _serializer.uint32(obj.strokes.length, buffer, bufferOffset);
    obj.strokes.forEach((val) => {
      bufferOffset = Stroke.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Strokes
    let len;
    let data = new Strokes(null);
    // Deserialize message field [strokes]
    // Deserialize array length for message field [strokes]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.strokes = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.strokes[i] = Stroke.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 40 * object.strokes.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/Strokes';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '45667f7f16ec4ce03c620652cf52dd9a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Stroke[] strokes
    
    ================================================================================
    MSG: hr_msgs/Stroke
    float64 target_x # target position on canvas in meters
    float64 target_y # target position on canvas in meters
    float64 speed # speed in m/s, hack: negative speed will be interpreted as a stop motion in seconds
    float64 penHeight # distance of the pen from the canvas in meters
    float64 scale_done_dist # this should be by default 1., larger values (like 2.) make the drawing less precise but "faster" in execution
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Strokes(null);
    if (msg.strokes !== undefined) {
      resolved.strokes = new Array(msg.strokes.length);
      for (let i = 0; i < resolved.strokes.length; ++i) {
        resolved.strokes[i] = Stroke.Resolve(msg.strokes[i]);
      }
    }
    else {
      resolved.strokes = []
    }

    return resolved;
    }
};

module.exports = Strokes;
