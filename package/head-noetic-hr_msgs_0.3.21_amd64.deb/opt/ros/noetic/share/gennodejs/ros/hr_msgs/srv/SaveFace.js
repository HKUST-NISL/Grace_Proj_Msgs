// Auto-generated. Do not edit!

// (in-package hr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SaveFaceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.face_id = null;
      this.new_face_id = null;
      this.prop_names = null;
      this.prop_values = null;
    }
    else {
      if (initObj.hasOwnProperty('face_id')) {
        this.face_id = initObj.face_id
      }
      else {
        this.face_id = '';
      }
      if (initObj.hasOwnProperty('new_face_id')) {
        this.new_face_id = initObj.new_face_id
      }
      else {
        this.new_face_id = '';
      }
      if (initObj.hasOwnProperty('prop_names')) {
        this.prop_names = initObj.prop_names
      }
      else {
        this.prop_names = [];
      }
      if (initObj.hasOwnProperty('prop_values')) {
        this.prop_values = initObj.prop_values
      }
      else {
        this.prop_values = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SaveFaceRequest
    // Serialize message field [face_id]
    bufferOffset = _serializer.string(obj.face_id, buffer, bufferOffset);
    // Serialize message field [new_face_id]
    bufferOffset = _serializer.string(obj.new_face_id, buffer, bufferOffset);
    // Serialize message field [prop_names]
    bufferOffset = _arraySerializer.string(obj.prop_names, buffer, bufferOffset, null);
    // Serialize message field [prop_values]
    bufferOffset = _arraySerializer.string(obj.prop_values, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SaveFaceRequest
    let len;
    let data = new SaveFaceRequest(null);
    // Deserialize message field [face_id]
    data.face_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [new_face_id]
    data.new_face_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [prop_names]
    data.prop_names = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [prop_values]
    data.prop_values = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.face_id.length;
    length += object.new_face_id.length;
    object.prop_names.forEach((val) => {
      length += 4 + val.length;
    });
    object.prop_values.forEach((val) => {
      length += 4 + val.length;
    });
    return length + 16;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/SaveFaceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ea4946b9f8ca6573abb2259060a1694d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string      face_id
    string      new_face_id
    string[]    prop_names
    string[]    prop_values
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SaveFaceRequest(null);
    if (msg.face_id !== undefined) {
      resolved.face_id = msg.face_id;
    }
    else {
      resolved.face_id = ''
    }

    if (msg.new_face_id !== undefined) {
      resolved.new_face_id = msg.new_face_id;
    }
    else {
      resolved.new_face_id = ''
    }

    if (msg.prop_names !== undefined) {
      resolved.prop_names = msg.prop_names;
    }
    else {
      resolved.prop_names = []
    }

    if (msg.prop_values !== undefined) {
      resolved.prop_values = msg.prop_values;
    }
    else {
      resolved.prop_values = []
    }

    return resolved;
    }
};

class SaveFaceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.face_id = null;
      this.error = null;
    }
    else {
      if (initObj.hasOwnProperty('face_id')) {
        this.face_id = initObj.face_id
      }
      else {
        this.face_id = '';
      }
      if (initObj.hasOwnProperty('error')) {
        this.error = initObj.error
      }
      else {
        this.error = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SaveFaceResponse
    // Serialize message field [face_id]
    bufferOffset = _serializer.string(obj.face_id, buffer, bufferOffset);
    // Serialize message field [error]
    bufferOffset = _serializer.string(obj.error, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SaveFaceResponse
    let len;
    let data = new SaveFaceResponse(null);
    // Deserialize message field [face_id]
    data.face_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [error]
    data.error = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.face_id.length;
    length += object.error.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/SaveFaceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3d2b884fc56116666e5377587e42fa51';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string face_id
    string error
    
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SaveFaceResponse(null);
    if (msg.face_id !== undefined) {
      resolved.face_id = msg.face_id;
    }
    else {
      resolved.face_id = ''
    }

    if (msg.error !== undefined) {
      resolved.error = msg.error;
    }
    else {
      resolved.error = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SaveFaceRequest,
  Response: SaveFaceResponse,
  md5sum() { return 'b5baaa7ec98c671ba6ed10ae039c5f0b'; },
  datatype() { return 'hr_msgs/SaveFace'; }
};
