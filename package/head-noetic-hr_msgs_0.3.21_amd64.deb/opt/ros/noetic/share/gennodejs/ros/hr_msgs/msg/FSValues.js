// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let FSShapekeys = require('./FSShapekeys.js');
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class FSValues {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.tracking_status = null;
      this.head_pose = null;
      this.eye_left = null;
      this.eye_right = null;
      this.keys = null;
    }
    else {
      if (initObj.hasOwnProperty('tracking_status')) {
        this.tracking_status = initObj.tracking_status
      }
      else {
        this.tracking_status = new std_msgs.msg.Bool();
      }
      if (initObj.hasOwnProperty('head_pose')) {
        this.head_pose = initObj.head_pose
      }
      else {
        this.head_pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('eye_left')) {
        this.eye_left = initObj.eye_left
      }
      else {
        this.eye_left = new geometry_msgs.msg.Vector3();
      }
      if (initObj.hasOwnProperty('eye_right')) {
        this.eye_right = initObj.eye_right
      }
      else {
        this.eye_right = new geometry_msgs.msg.Vector3();
      }
      if (initObj.hasOwnProperty('keys')) {
        this.keys = initObj.keys
      }
      else {
        this.keys = new FSShapekeys();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FSValues
    // Serialize message field [tracking_status]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.tracking_status, buffer, bufferOffset);
    // Serialize message field [head_pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.head_pose, buffer, bufferOffset);
    // Serialize message field [eye_left]
    bufferOffset = geometry_msgs.msg.Vector3.serialize(obj.eye_left, buffer, bufferOffset);
    // Serialize message field [eye_right]
    bufferOffset = geometry_msgs.msg.Vector3.serialize(obj.eye_right, buffer, bufferOffset);
    // Serialize message field [keys]
    bufferOffset = FSShapekeys.serialize(obj.keys, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FSValues
    let len;
    let data = new FSValues(null);
    // Deserialize message field [tracking_status]
    data.tracking_status = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    // Deserialize message field [head_pose]
    data.head_pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [eye_left]
    data.eye_left = geometry_msgs.msg.Vector3.deserialize(buffer, bufferOffset);
    // Deserialize message field [eye_right]
    data.eye_right = geometry_msgs.msg.Vector3.deserialize(buffer, bufferOffset);
    // Deserialize message field [keys]
    data.keys = FSShapekeys.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += FSShapekeys.getMessageSize(object.keys);
    return length + 105;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/FSValues';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '829d3b6552e62af9fcb32c6db65e1f8a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Bool tracking_status
    geometry_msgs/Pose head_pose
    geometry_msgs/Vector3 eye_left
    geometry_msgs/Vector3 eye_right
    FSShapekeys keys
    ================================================================================
    MSG: std_msgs/Bool
    bool data
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    ================================================================================
    MSG: hr_msgs/FSShapekeys
    FSShapekey[] shapekey
    
    ================================================================================
    MSG: hr_msgs/FSShapekey
    string name
    float32 value
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FSValues(null);
    if (msg.tracking_status !== undefined) {
      resolved.tracking_status = std_msgs.msg.Bool.Resolve(msg.tracking_status)
    }
    else {
      resolved.tracking_status = new std_msgs.msg.Bool()
    }

    if (msg.head_pose !== undefined) {
      resolved.head_pose = geometry_msgs.msg.Pose.Resolve(msg.head_pose)
    }
    else {
      resolved.head_pose = new geometry_msgs.msg.Pose()
    }

    if (msg.eye_left !== undefined) {
      resolved.eye_left = geometry_msgs.msg.Vector3.Resolve(msg.eye_left)
    }
    else {
      resolved.eye_left = new geometry_msgs.msg.Vector3()
    }

    if (msg.eye_right !== undefined) {
      resolved.eye_right = geometry_msgs.msg.Vector3.Resolve(msg.eye_right)
    }
    else {
      resolved.eye_right = new geometry_msgs.msg.Vector3()
    }

    if (msg.keys !== undefined) {
      resolved.keys = FSShapekeys.Resolve(msg.keys)
    }
    else {
      resolved.keys = new FSShapekeys()
    }

    return resolved;
    }
};

module.exports = FSValues;
