// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class SourceInfoWithCovariance {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.source_id = null;
      this.pose = null;
      this.source_probability = null;
      this.separation_data = null;
      this.postfiltered_data = null;
    }
    else {
      if (initObj.hasOwnProperty('source_id')) {
        this.source_id = initObj.source_id
      }
      else {
        this.source_id = 0;
      }
      if (initObj.hasOwnProperty('pose')) {
        this.pose = initObj.pose
      }
      else {
        this.pose = new geometry_msgs.msg.PoseWithCovarianceStamped();
      }
      if (initObj.hasOwnProperty('source_probability')) {
        this.source_probability = initObj.source_probability
      }
      else {
        this.source_probability = 0.0;
      }
      if (initObj.hasOwnProperty('separation_data')) {
        this.separation_data = initObj.separation_data
      }
      else {
        this.separation_data = [];
      }
      if (initObj.hasOwnProperty('postfiltered_data')) {
        this.postfiltered_data = initObj.postfiltered_data
      }
      else {
        this.postfiltered_data = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SourceInfoWithCovariance
    // Serialize message field [source_id]
    bufferOffset = _serializer.uint32(obj.source_id, buffer, bufferOffset);
    // Serialize message field [pose]
    bufferOffset = geometry_msgs.msg.PoseWithCovarianceStamped.serialize(obj.pose, buffer, bufferOffset);
    // Serialize message field [source_probability]
    bufferOffset = _serializer.float32(obj.source_probability, buffer, bufferOffset);
    // Serialize message field [separation_data]
    bufferOffset = _arraySerializer.float32(obj.separation_data, buffer, bufferOffset, null);
    // Serialize message field [postfiltered_data]
    bufferOffset = _arraySerializer.float32(obj.postfiltered_data, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SourceInfoWithCovariance
    let len;
    let data = new SourceInfoWithCovariance(null);
    // Deserialize message field [source_id]
    data.source_id = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [pose]
    data.pose = geometry_msgs.msg.PoseWithCovarianceStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [source_probability]
    data.source_probability = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [separation_data]
    data.separation_data = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [postfiltered_data]
    data.postfiltered_data = _arrayDeserializer.float32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += geometry_msgs.msg.PoseWithCovarianceStamped.getMessageSize(object.pose);
    length += 4 * object.separation_data.length;
    length += 4 * object.postfiltered_data.length;
    return length + 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/SourceInfoWithCovariance';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0a935a273a55fd1e2e2cf21ca3fbcd68';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # A source info message with a 3D-localized source with covariance.
    # Replaces the point + latitude and longitude info of a standard SourceInfo
    # message.
    
    uint32 source_id
    geometry_msgs/PoseWithCovarianceStamped pose
    float32 source_probability
    float32[] separation_data # Separation data (audio stream)
    float32[] postfiltered_data # Postfiltered data (audio stream)
    
    
    ================================================================================
    MSG: geometry_msgs/PoseWithCovarianceStamped
    # This expresses an estimated pose with a reference coordinate frame and timestamp
    
    Header header
    PoseWithCovariance pose
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/PoseWithCovariance
    # This represents a pose in free space with uncertainty.
    
    Pose pose
    
    # Row-major representation of the 6x6 covariance matrix
    # The orientation parameters use a fixed-axis representation.
    # In order, the parameters are:
    # (x, y, z, rotation about X axis, rotation about Y axis, rotation about Z axis)
    float64[36] covariance
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SourceInfoWithCovariance(null);
    if (msg.source_id !== undefined) {
      resolved.source_id = msg.source_id;
    }
    else {
      resolved.source_id = 0
    }

    if (msg.pose !== undefined) {
      resolved.pose = geometry_msgs.msg.PoseWithCovarianceStamped.Resolve(msg.pose)
    }
    else {
      resolved.pose = new geometry_msgs.msg.PoseWithCovarianceStamped()
    }

    if (msg.source_probability !== undefined) {
      resolved.source_probability = msg.source_probability;
    }
    else {
      resolved.source_probability = 0.0
    }

    if (msg.separation_data !== undefined) {
      resolved.separation_data = msg.separation_data;
    }
    else {
      resolved.separation_data = []
    }

    if (msg.postfiltered_data !== undefined) {
      resolved.postfiltered_data = msg.postfiltered_data;
    }
    else {
      resolved.postfiltered_data = []
    }

    return resolved;
    }
};

module.exports = SourceInfoWithCovariance;
