// Auto-generated. Do not edit!

// (in-package grace_attn_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class DialogueLog {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.emergency = null;
      this.disengage = null;
      this.log = null;
      this.transcript = null;
    }
    else {
      if (initObj.hasOwnProperty('emergency')) {
        this.emergency = initObj.emergency
      }
      else {
        this.emergency = new std_msgs.msg.Bool();
      }
      if (initObj.hasOwnProperty('disengage')) {
        this.disengage = initObj.disengage
      }
      else {
        this.disengage = new std_msgs.msg.Bool();
      }
      if (initObj.hasOwnProperty('log')) {
        this.log = initObj.log
      }
      else {
        this.log = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('transcript')) {
        this.transcript = initObj.transcript
      }
      else {
        this.transcript = new std_msgs.msg.String();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DialogueLog
    // Serialize message field [emergency]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.emergency, buffer, bufferOffset);
    // Serialize message field [disengage]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.disengage, buffer, bufferOffset);
    // Serialize message field [log]
    bufferOffset = std_msgs.msg.String.serialize(obj.log, buffer, bufferOffset);
    // Serialize message field [transcript]
    bufferOffset = std_msgs.msg.String.serialize(obj.transcript, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DialogueLog
    let len;
    let data = new DialogueLog(null);
    // Deserialize message field [emergency]
    data.emergency = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    // Deserialize message field [disengage]
    data.disengage = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    // Deserialize message field [log]
    data.log = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [transcript]
    data.transcript = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.log);
    length += std_msgs.msg.String.getMessageSize(object.transcript);
    return length + 2;
  }

  static datatype() {
    // Returns string type for a message object
    return 'grace_attn_msgs/DialogueLog';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c9957ab86b09131513bd48c43a6329fe';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Bool emergency
    std_msgs/Bool disengage
    std_msgs/String log
    std_msgs/String transcript
    ================================================================================
    MSG: std_msgs/Bool
    bool data
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DialogueLog(null);
    if (msg.emergency !== undefined) {
      resolved.emergency = std_msgs.msg.Bool.Resolve(msg.emergency)
    }
    else {
      resolved.emergency = new std_msgs.msg.Bool()
    }

    if (msg.disengage !== undefined) {
      resolved.disengage = std_msgs.msg.Bool.Resolve(msg.disengage)
    }
    else {
      resolved.disengage = new std_msgs.msg.Bool()
    }

    if (msg.log !== undefined) {
      resolved.log = std_msgs.msg.String.Resolve(msg.log)
    }
    else {
      resolved.log = new std_msgs.msg.String()
    }

    if (msg.transcript !== undefined) {
      resolved.transcript = std_msgs.msg.String.Resolve(msg.transcript)
    }
    else {
      resolved.transcript = new std_msgs.msg.String()
    }

    return resolved;
    }
};

module.exports = DialogueLog;
