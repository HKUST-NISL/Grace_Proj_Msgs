// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Status {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.has_current_target = null;
      this.current_target_x = null;
      this.current_target_y = null;
      this.has_current_pen_on_canvas = null;
      this.current_pen_on_canvas_x = null;
      this.current_pen_on_canvas_y = null;
      this.current_pen_x = null;
      this.current_pen_y = null;
      this.current_pen_z = null;
      this.queue = null;
    }
    else {
      if (initObj.hasOwnProperty('has_current_target')) {
        this.has_current_target = initObj.has_current_target
      }
      else {
        this.has_current_target = false;
      }
      if (initObj.hasOwnProperty('current_target_x')) {
        this.current_target_x = initObj.current_target_x
      }
      else {
        this.current_target_x = 0.0;
      }
      if (initObj.hasOwnProperty('current_target_y')) {
        this.current_target_y = initObj.current_target_y
      }
      else {
        this.current_target_y = 0.0;
      }
      if (initObj.hasOwnProperty('has_current_pen_on_canvas')) {
        this.has_current_pen_on_canvas = initObj.has_current_pen_on_canvas
      }
      else {
        this.has_current_pen_on_canvas = false;
      }
      if (initObj.hasOwnProperty('current_pen_on_canvas_x')) {
        this.current_pen_on_canvas_x = initObj.current_pen_on_canvas_x
      }
      else {
        this.current_pen_on_canvas_x = 0.0;
      }
      if (initObj.hasOwnProperty('current_pen_on_canvas_y')) {
        this.current_pen_on_canvas_y = initObj.current_pen_on_canvas_y
      }
      else {
        this.current_pen_on_canvas_y = 0.0;
      }
      if (initObj.hasOwnProperty('current_pen_x')) {
        this.current_pen_x = initObj.current_pen_x
      }
      else {
        this.current_pen_x = 0.0;
      }
      if (initObj.hasOwnProperty('current_pen_y')) {
        this.current_pen_y = initObj.current_pen_y
      }
      else {
        this.current_pen_y = 0.0;
      }
      if (initObj.hasOwnProperty('current_pen_z')) {
        this.current_pen_z = initObj.current_pen_z
      }
      else {
        this.current_pen_z = 0.0;
      }
      if (initObj.hasOwnProperty('queue')) {
        this.queue = initObj.queue
      }
      else {
        this.queue = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Status
    // Serialize message field [has_current_target]
    bufferOffset = _serializer.bool(obj.has_current_target, buffer, bufferOffset);
    // Serialize message field [current_target_x]
    bufferOffset = _serializer.float64(obj.current_target_x, buffer, bufferOffset);
    // Serialize message field [current_target_y]
    bufferOffset = _serializer.float64(obj.current_target_y, buffer, bufferOffset);
    // Serialize message field [has_current_pen_on_canvas]
    bufferOffset = _serializer.bool(obj.has_current_pen_on_canvas, buffer, bufferOffset);
    // Serialize message field [current_pen_on_canvas_x]
    bufferOffset = _serializer.float64(obj.current_pen_on_canvas_x, buffer, bufferOffset);
    // Serialize message field [current_pen_on_canvas_y]
    bufferOffset = _serializer.float64(obj.current_pen_on_canvas_y, buffer, bufferOffset);
    // Serialize message field [current_pen_x]
    bufferOffset = _serializer.float64(obj.current_pen_x, buffer, bufferOffset);
    // Serialize message field [current_pen_y]
    bufferOffset = _serializer.float64(obj.current_pen_y, buffer, bufferOffset);
    // Serialize message field [current_pen_z]
    bufferOffset = _serializer.float64(obj.current_pen_z, buffer, bufferOffset);
    // Serialize message field [queue]
    bufferOffset = _serializer.int32(obj.queue, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Status
    let len;
    let data = new Status(null);
    // Deserialize message field [has_current_target]
    data.has_current_target = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [current_target_x]
    data.current_target_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [current_target_y]
    data.current_target_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [has_current_pen_on_canvas]
    data.has_current_pen_on_canvas = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [current_pen_on_canvas_x]
    data.current_pen_on_canvas_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [current_pen_on_canvas_y]
    data.current_pen_on_canvas_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [current_pen_x]
    data.current_pen_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [current_pen_y]
    data.current_pen_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [current_pen_z]
    data.current_pen_z = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [queue]
    data.queue = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 62;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/Status';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b2f1182303ddbcf575606c28e2f841de';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool has_current_target    # indicates if the robot arm is currently moved
    
    float64 current_target_x   # x/y position of the current goal (only valid if has_current_target is true)
    float64 current_target_y
    
    bool has_current_pen_on_canvas   # indicates if the current_pen_on_canvas values are valid
    float64 current_pen_on_canvas_x  # current x/y position of the pen on the canvas
    float64 current_pen_on_canvas_y
    
    float64 current_pen_x            # current x/y/z position of pen in 3d space
    float64 current_pen_y
    float64 current_pen_z
    
    int32 queue                # amount of strokes that are still in the queue
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Status(null);
    if (msg.has_current_target !== undefined) {
      resolved.has_current_target = msg.has_current_target;
    }
    else {
      resolved.has_current_target = false
    }

    if (msg.current_target_x !== undefined) {
      resolved.current_target_x = msg.current_target_x;
    }
    else {
      resolved.current_target_x = 0.0
    }

    if (msg.current_target_y !== undefined) {
      resolved.current_target_y = msg.current_target_y;
    }
    else {
      resolved.current_target_y = 0.0
    }

    if (msg.has_current_pen_on_canvas !== undefined) {
      resolved.has_current_pen_on_canvas = msg.has_current_pen_on_canvas;
    }
    else {
      resolved.has_current_pen_on_canvas = false
    }

    if (msg.current_pen_on_canvas_x !== undefined) {
      resolved.current_pen_on_canvas_x = msg.current_pen_on_canvas_x;
    }
    else {
      resolved.current_pen_on_canvas_x = 0.0
    }

    if (msg.current_pen_on_canvas_y !== undefined) {
      resolved.current_pen_on_canvas_y = msg.current_pen_on_canvas_y;
    }
    else {
      resolved.current_pen_on_canvas_y = 0.0
    }

    if (msg.current_pen_x !== undefined) {
      resolved.current_pen_x = msg.current_pen_x;
    }
    else {
      resolved.current_pen_x = 0.0
    }

    if (msg.current_pen_y !== undefined) {
      resolved.current_pen_y = msg.current_pen_y;
    }
    else {
      resolved.current_pen_y = 0.0
    }

    if (msg.current_pen_z !== undefined) {
      resolved.current_pen_z = msg.current_pen_z;
    }
    else {
      resolved.current_pen_z = 0.0
    }

    if (msg.queue !== undefined) {
      resolved.queue = msg.queue;
    }
    else {
      resolved.queue = 0
    }

    return resolved;
    }
};

module.exports = Status;
