
"use strict";

let AgentChat = require('./AgentChat.js')
let SetMode = require('./SetMode.js')
let MotorStates = require('./MotorStates.js')
let SetScene = require('./SetScene.js')
let GetInteger = require('./GetInteger.js')
let GetIntent = require('./GetIntent.js')
let SetParam = require('./SetParam.js')
let StringArray = require('./StringArray.js')
let UpdateMotors = require('./UpdateMotors.js')
let ResetMotors = require('./ResetMotors.js')
let RunByName = require('./RunByName.js')
let MotorValuesBool = require('./MotorValuesBool.js')
let GetAnimationLength = require('./GetAnimationLength.js')
let TTSData = require('./TTSData.js')
let SaveFace = require('./SaveFace.js')
let TTSLength = require('./TTSLength.js')
let MotorValues = require('./MotorValues.js')
let NodeAction = require('./NodeAction.js')
let AgentRegister = require('./AgentRegister.js')
let ConfigurableNodes = require('./ConfigurableNodes.js')
let ChatService = require('./ChatService.js')
let SetProperties = require('./SetProperties.js')
let Current = require('./Current.js')
let GetMode = require('./GetMode.js')
let MotionManagement = require('./MotionManagement.js')
let PerformanceCommand = require('./PerformanceCommand.js')
let NodeDescription = require('./NodeDescription.js')
let FaceId = require('./FaceId.js')
let Load = require('./Load.js')
let StringTrigger = require('./StringTrigger.js')
let TTSTrigger = require('./TTSTrigger.js')
let SetActuatorsControl = require('./SetActuatorsControl.js')
let AgentUnregister = require('./AgentUnregister.js')
let LoadPerformance = require('./LoadPerformance.js')
let Resume = require('./Resume.js')
let NodeConfiguration = require('./NodeConfiguration.js')
let FaceLandmarks = require('./FaceLandmarks.js')
let Run = require('./Run.js')
let Pause = require('./Pause.js')
let UpdateExpressions = require('./UpdateExpressions.js')
let Json = require('./Json.js')
let Emotion = require('./Emotion.js')
let Stop = require('./Stop.js')
let AnimationLength = require('./AnimationLength.js')
let EyeState = require('./EyeState.js')
let ChatSession = require('./ChatSession.js')
let GetParam = require('./GetParam.js')
let ValidFaceExprs = require('./ValidFaceExprs.js')

module.exports = {
  AgentChat: AgentChat,
  SetMode: SetMode,
  MotorStates: MotorStates,
  SetScene: SetScene,
  GetInteger: GetInteger,
  GetIntent: GetIntent,
  SetParam: SetParam,
  StringArray: StringArray,
  UpdateMotors: UpdateMotors,
  ResetMotors: ResetMotors,
  RunByName: RunByName,
  MotorValuesBool: MotorValuesBool,
  GetAnimationLength: GetAnimationLength,
  TTSData: TTSData,
  SaveFace: SaveFace,
  TTSLength: TTSLength,
  MotorValues: MotorValues,
  NodeAction: NodeAction,
  AgentRegister: AgentRegister,
  ConfigurableNodes: ConfigurableNodes,
  ChatService: ChatService,
  SetProperties: SetProperties,
  Current: Current,
  GetMode: GetMode,
  MotionManagement: MotionManagement,
  PerformanceCommand: PerformanceCommand,
  NodeDescription: NodeDescription,
  FaceId: FaceId,
  Load: Load,
  StringTrigger: StringTrigger,
  TTSTrigger: TTSTrigger,
  SetActuatorsControl: SetActuatorsControl,
  AgentUnregister: AgentUnregister,
  LoadPerformance: LoadPerformance,
  Resume: Resume,
  NodeConfiguration: NodeConfiguration,
  FaceLandmarks: FaceLandmarks,
  Run: Run,
  Pause: Pause,
  UpdateExpressions: UpdateExpressions,
  Json: Json,
  Emotion: Emotion,
  Stop: Stop,
  AnimationLength: AnimationLength,
  EyeState: EyeState,
  ChatSession: ChatSession,
  GetParam: GetParam,
  ValidFaceExprs: ValidFaceExprs,
};
