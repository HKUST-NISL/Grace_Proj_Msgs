// Auto-generated. Do not edit!

// (in-package hr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetActuatorsControlRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.control = null;
      this.actuators = null;
    }
    else {
      if (initObj.hasOwnProperty('control')) {
        this.control = initObj.control
      }
      else {
        this.control = 0;
      }
      if (initObj.hasOwnProperty('actuators')) {
        this.actuators = initObj.actuators
      }
      else {
        this.actuators = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetActuatorsControlRequest
    // Serialize message field [control]
    bufferOffset = _serializer.int32(obj.control, buffer, bufferOffset);
    // Serialize message field [actuators]
    bufferOffset = _arraySerializer.string(obj.actuators, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetActuatorsControlRequest
    let len;
    let data = new SetActuatorsControlRequest(null);
    // Deserialize message field [control]
    data.control = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [actuators]
    data.actuators = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.actuators.forEach((val) => {
      length += 4 + val.length;
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/SetActuatorsControlRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e202cde8923c9be941af721b13d947b8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    int32 CONTROL_DISABLE = 0
    int32 CONTROL_MANUAL   = 1
    int32 CONTROL_ANIMATION = 2
    int32 control
    
    
    string[] actuators
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetActuatorsControlRequest(null);
    if (msg.control !== undefined) {
      resolved.control = msg.control;
    }
    else {
      resolved.control = 0
    }

    if (msg.actuators !== undefined) {
      resolved.actuators = msg.actuators;
    }
    else {
      resolved.actuators = []
    }

    return resolved;
    }
};

// Constants for message
SetActuatorsControlRequest.Constants = {
  CONTROL_DISABLE: 0,
  CONTROL_MANUAL: 1,
  CONTROL_ANIMATION: 2,
}

class SetActuatorsControlResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.error = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('error')) {
        this.error = initObj.error
      }
      else {
        this.error = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetActuatorsControlResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [error]
    bufferOffset = _serializer.string(obj.error, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetActuatorsControlResponse
    let len;
    let data = new SetActuatorsControlResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [error]
    data.error = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.error.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/SetActuatorsControlResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '45872d25d65c97743cc71afc6d4e884d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    bool success
    
    
    string error
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetActuatorsControlResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.error !== undefined) {
      resolved.error = msg.error;
    }
    else {
      resolved.error = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SetActuatorsControlRequest,
  Response: SetActuatorsControlResponse,
  md5sum() { return '22e98a4c99b40f7c39d3409d7a7e482a'; },
  datatype() { return 'hr_msgs/SetActuatorsControl'; }
};
