// Auto-generated. Do not edit!

// (in-package hr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class ValidFaceExprsRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ValidFaceExprsRequest
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ValidFaceExprsRequest
    let len;
    let data = new ValidFaceExprsRequest(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/ValidFaceExprsRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ValidFaceExprsRequest(null);
    return resolved;
    }
};

class ValidFaceExprsResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.exprnames = null;
    }
    else {
      if (initObj.hasOwnProperty('exprnames')) {
        this.exprnames = initObj.exprnames
      }
      else {
        this.exprnames = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ValidFaceExprsResponse
    // Serialize message field [exprnames]
    bufferOffset = _arraySerializer.string(obj.exprnames, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ValidFaceExprsResponse
    let len;
    let data = new ValidFaceExprsResponse(null);
    // Deserialize message field [exprnames]
    data.exprnames = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.exprnames.forEach((val) => {
      length += 4 + val.length;
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/ValidFaceExprsResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '961110ff326afbad135f5b318e4e8821';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string[] exprnames
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ValidFaceExprsResponse(null);
    if (msg.exprnames !== undefined) {
      resolved.exprnames = msg.exprnames;
    }
    else {
      resolved.exprnames = []
    }

    return resolved;
    }
};

module.exports = {
  Request: ValidFaceExprsRequest,
  Response: ValidFaceExprsResponse,
  md5sum() { return '961110ff326afbad135f5b318e4e8821'; },
  datatype() { return 'hr_msgs/ValidFaceExprs'; }
};
