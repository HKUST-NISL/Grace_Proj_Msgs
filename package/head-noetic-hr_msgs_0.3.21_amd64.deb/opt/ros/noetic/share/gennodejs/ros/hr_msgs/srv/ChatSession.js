// Auto-generated. Do not edit!

// (in-package hr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class ChatSessionRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.session = null;
    }
    else {
      if (initObj.hasOwnProperty('session')) {
        this.session = initObj.session
      }
      else {
        this.session = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ChatSessionRequest
    // Serialize message field [session]
    bufferOffset = _serializer.string(obj.session, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ChatSessionRequest
    let len;
    let data = new ChatSessionRequest(null);
    // Deserialize message field [session]
    data.session = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.session.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/ChatSessionRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'cdb023ea82c30a490ca38b85150a3d88';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string session
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ChatSessionRequest(null);
    if (msg.session !== undefined) {
      resolved.session = msg.session;
    }
    else {
      resolved.session = ''
    }

    return resolved;
    }
};

class ChatSessionResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.session = null;
    }
    else {
      if (initObj.hasOwnProperty('session')) {
        this.session = initObj.session
      }
      else {
        this.session = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ChatSessionResponse
    // Serialize message field [session]
    bufferOffset = _serializer.string(obj.session, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ChatSessionResponse
    let len;
    let data = new ChatSessionResponse(null);
    // Deserialize message field [session]
    data.session = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.session.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/ChatSessionResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'cdb023ea82c30a490ca38b85150a3d88';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string session
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ChatSessionResponse(null);
    if (msg.session !== undefined) {
      resolved.session = msg.session;
    }
    else {
      resolved.session = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: ChatSessionRequest,
  Response: ChatSessionResponse,
  md5sum() { return '962a90b72adb97ec4cb838d18c5cb180'; },
  datatype() { return 'hr_msgs/ChatSession'; }
};
