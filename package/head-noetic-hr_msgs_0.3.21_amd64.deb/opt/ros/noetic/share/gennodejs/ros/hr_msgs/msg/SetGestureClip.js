// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class SetGestureClip {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.repeat = null;
      this.speed = null;
      this.magnitude = null;
      this.start_time = null;
      this.end_time = null;
      this.ease_in = null;
      this.ease_out = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('repeat')) {
        this.repeat = initObj.repeat
      }
      else {
        this.repeat = 0;
      }
      if (initObj.hasOwnProperty('speed')) {
        this.speed = initObj.speed
      }
      else {
        this.speed = 0.0;
      }
      if (initObj.hasOwnProperty('magnitude')) {
        this.magnitude = initObj.magnitude
      }
      else {
        this.magnitude = 0.0;
      }
      if (initObj.hasOwnProperty('start_time')) {
        this.start_time = initObj.start_time
      }
      else {
        this.start_time = 0.0;
      }
      if (initObj.hasOwnProperty('end_time')) {
        this.end_time = initObj.end_time
      }
      else {
        this.end_time = 0.0;
      }
      if (initObj.hasOwnProperty('ease_in')) {
        this.ease_in = initObj.ease_in
      }
      else {
        this.ease_in = 0.0;
      }
      if (initObj.hasOwnProperty('ease_out')) {
        this.ease_out = initObj.ease_out
      }
      else {
        this.ease_out = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetGestureClip
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [repeat]
    bufferOffset = _serializer.int32(obj.repeat, buffer, bufferOffset);
    // Serialize message field [speed]
    bufferOffset = _serializer.float32(obj.speed, buffer, bufferOffset);
    // Serialize message field [magnitude]
    bufferOffset = _serializer.float32(obj.magnitude, buffer, bufferOffset);
    // Serialize message field [start_time]
    bufferOffset = _serializer.float32(obj.start_time, buffer, bufferOffset);
    // Serialize message field [end_time]
    bufferOffset = _serializer.float32(obj.end_time, buffer, bufferOffset);
    // Serialize message field [ease_in]
    bufferOffset = _serializer.float32(obj.ease_in, buffer, bufferOffset);
    // Serialize message field [ease_out]
    bufferOffset = _serializer.float32(obj.ease_out, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetGestureClip
    let len;
    let data = new SetGestureClip(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [repeat]
    data.repeat = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [speed]
    data.speed = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [magnitude]
    data.magnitude = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [start_time]
    data.start_time = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [end_time]
    data.end_time = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [ease_in]
    data.ease_in = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [ease_out]
    data.ease_out = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name.length;
    return length + 32;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/SetGestureClip';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2b055ec281c545d9b634b33a1ec5a5bf';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string name
    int32 repeat
    float32 speed
    float32 magnitude
    float32 start_time
    float32 end_time
    float32 ease_in
    float32 ease_out
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetGestureClip(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.repeat !== undefined) {
      resolved.repeat = msg.repeat;
    }
    else {
      resolved.repeat = 0
    }

    if (msg.speed !== undefined) {
      resolved.speed = msg.speed;
    }
    else {
      resolved.speed = 0.0
    }

    if (msg.magnitude !== undefined) {
      resolved.magnitude = msg.magnitude;
    }
    else {
      resolved.magnitude = 0.0
    }

    if (msg.start_time !== undefined) {
      resolved.start_time = msg.start_time;
    }
    else {
      resolved.start_time = 0.0
    }

    if (msg.end_time !== undefined) {
      resolved.end_time = msg.end_time;
    }
    else {
      resolved.end_time = 0.0
    }

    if (msg.ease_in !== undefined) {
      resolved.ease_in = msg.ease_in;
    }
    else {
      resolved.ease_in = 0.0
    }

    if (msg.ease_out !== undefined) {
      resolved.ease_out = msg.ease_out;
    }
    else {
      resolved.ease_out = 0.0
    }

    return resolved;
    }
};

module.exports = SetGestureClip;
